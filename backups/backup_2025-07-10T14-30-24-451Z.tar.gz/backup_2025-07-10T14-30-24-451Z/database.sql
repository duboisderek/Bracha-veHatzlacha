--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_wallets; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.admin_wallets (
    currency character varying NOT NULL,
    address character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.admin_wallets OWNER TO neondb_owner;

--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.chat_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    message text NOT NULL,
    is_from_admin boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.chat_messages OWNER TO neondb_owner;

--
-- Name: crypto_payments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.crypto_payments (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    amount numeric(10,2) NOT NULL,
    tx_hash character varying NOT NULL,
    wallet_address character varying NOT NULL,
    currency character varying NOT NULL,
    status character varying NOT NULL,
    submitted_at timestamp without time zone DEFAULT now(),
    processed_at timestamp without time zone,
    processed_by character varying,
    notes text
);


ALTER TABLE public.crypto_payments OWNER TO neondb_owner;

--
-- Name: draws; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.draws (
    id integer NOT NULL,
    draw_number integer NOT NULL,
    draw_date timestamp without time zone NOT NULL,
    winning_numbers jsonb,
    jackpot_amount numeric(10,2) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_completed boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.draws OWNER TO neondb_owner;

--
-- Name: draws_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.draws_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.draws_id_seq OWNER TO neondb_owner;

--
-- Name: draws_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.draws_id_seq OWNED BY public.draws.id;


--
-- Name: referrals; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.referrals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    referrer_id character varying NOT NULL,
    referred_id character varying NOT NULL,
    bonus_amount numeric(10,2) DEFAULT '100'::numeric NOT NULL,
    has_made_deposit boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.referrals OWNER TO neondb_owner;

--
-- Name: security_events; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.security_events (
    id character varying NOT NULL,
    user_id character varying,
    event character varying NOT NULL,
    ip character varying NOT NULL,
    user_agent text NOT NULL,
    "timestamp" timestamp without time zone DEFAULT now(),
    severity character varying NOT NULL,
    blocked boolean DEFAULT false NOT NULL,
    details jsonb
);


ALTER TABLE public.security_events OWNER TO neondb_owner;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sessions (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO neondb_owner;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.system_settings (
    key character varying NOT NULL,
    value text NOT NULL,
    description text,
    updated_by character varying,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.system_settings OWNER TO neondb_owner;

--
-- Name: tickets; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tickets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    draw_id integer NOT NULL,
    numbers jsonb NOT NULL,
    cost numeric(10,2) NOT NULL,
    match_count integer DEFAULT 0,
    winning_amount numeric(10,2) DEFAULT '0'::numeric,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.tickets OWNER TO neondb_owner;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    type character varying NOT NULL,
    amount numeric(10,2) NOT NULL,
    description text NOT NULL,
    ticket_id uuid,
    created_at timestamp without time zone DEFAULT now(),
    admin_comment text
);


ALTER TABLE public.transactions OWNER TO neondb_owner;

--
-- Name: two_factor_auth; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.two_factor_auth (
    user_id character varying NOT NULL,
    secret character varying NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    backup_codes jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    enabled_at timestamp without time zone
);


ALTER TABLE public.two_factor_auth OWNER TO neondb_owner;

--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id character varying NOT NULL,
    email character varying,
    first_name character varying,
    last_name character varying,
    profile_image_url character varying,
    balance numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    total_winnings numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    referral_code character varying NOT NULL,
    referred_by character varying,
    referral_bonus numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    referral_count integer DEFAULT 0 NOT NULL,
    is_admin boolean DEFAULT false NOT NULL,
    language character varying(5) DEFAULT 'en'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    is_blocked boolean DEFAULT false NOT NULL,
    phone_number character varying,
    sms_notifications boolean DEFAULT true NOT NULL,
    is_root_admin boolean DEFAULT false NOT NULL,
    is_fictional boolean DEFAULT false NOT NULL,
    password character varying
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: draws id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.draws ALTER COLUMN id SET DEFAULT nextval('public.draws_id_seq'::regclass);


--
-- Data for Name: admin_wallets; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.admin_wallets (currency, address, is_active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.chat_messages (id, user_id, message, is_from_admin, created_at) FROM stdin;
\.


--
-- Data for Name: crypto_payments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.crypto_payments (id, user_id, amount, tx_hash, wallet_address, currency, status, submitted_at, processed_at, processed_by, notes) FROM stdin;
payment_1752156511468_hb9ekybr0	vip_client_test_2025	100.00	test_hash_vip_123	1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2	btc	approved	2025-07-10 14:08:31.468	2025-07-10 14:09:00.388	\N	\N
payment_1752156547026_0f0vw9e6v	vip_client_test_2025	100.00	test	pending_verification	invalid_coin	pending	2025-07-10 14:09:07.026	\N	\N	\N
\.


--
-- Data for Name: draws; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.draws (id, draw_number, draw_date, winning_numbers, jackpot_amount, is_active, is_completed, created_at) FROM stdin;
1	1248	2025-06-06 18:14:12.497	[1, 2, 3, 4, 5, 6]	87340.00	f	t	2025-06-04 18:14:12.487892
4	1249	2025-06-07 10:16:11.681	[8, 10, 11, 23, 24, 26]	87390.00	f	t	2025-06-05 10:16:11.702358
5	1250	2025-06-06 14:52:00	[7, 10, 12, 19, 23, 37]	100000.00	f	t	2025-06-05 10:52:42.76449
6	1251	2025-06-12 11:00:38.037	[3, 13, 16, 18, 23, 28]	40000.00	f	t	2025-06-05 11:00:38.057569
9	1254	2025-06-19 08:14:55.224	\N	40030.00	f	f	2025-06-12 08:14:55.246006
8	1253	2025-06-12 20:00:00	[7, 14, 21, 28, 35, 42]	100075.00	f	t	2025-06-11 16:24:08.957433
7	1252	2025-06-12 11:13:50.927	[7, 14, 21, 28, 35, 42]	16050.00	f	t	2025-06-05 11:13:50.947517
10	1255	2025-06-20 20:00:00	\N	50000.00	f	f	2025-06-17 08:59:19.043602
11	1256	2025-06-18 10:32:11.852	\N	30000.00	f	f	2025-06-17 10:32:13.980726
12	1257	2025-06-18 20:00:00	\N	75000.00	f	f	2025-06-17 10:48:47.519465
13	1258	2025-06-21 20:00:00	\N	60000.00	f	f	2025-06-17 11:27:16.847041
14	1259	2025-06-22 20:00:00	\N	65000.00	f	f	2025-06-17 11:57:53.553119
16	9999	2025-07-10 20:00:00	[7, 14, 21, 28, 35, 42]	50000.00	f	t	2025-07-09 18:39:55.43764
15	1260	2025-06-23 20:00:00	\N	70010.00	f	f	2025-06-18 09:57:41.141456
17	10000	2025-07-25 20:00:00	[5, 12, 18, 25, 31, 37]	90250.00	f	t	2025-07-10 14:03:14.194765
18	10001	2025-07-30 20:00:00	\N	133830.00	t	f	2025-07-10 14:06:25.333307
\.


--
-- Data for Name: referrals; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.referrals (id, referrer_id, referred_id, bonus_amount, has_made_deposit, created_at) FROM stdin;
\.


--
-- Data for Name: security_events; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.security_events (id, user_id, event, ip, user_agent, "timestamp", severity, blocked, details) FROM stdin;
84eebbd7-3c88-43b4-9ef4-f7d7b65f0959	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:33:26.983809	low	f	{"email": "root@brahatz.com", "attemptNumber": 1}
f2b5eaae-e036-4b83-8884-7031720102d8	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:33:27.066782	low	f	{"email": "root@brahatz.com", "attemptNumber": 2}
a7ecd9bd-5424-4505-b9af-c18c76f649d9	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:33:27.681922	low	f	{"email": "admin@brahatz.com", "attemptNumber": 1}
877ce00f-eb75-405d-9860-b3149281d160	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:33:27.762176	low	f	{"email": "admin@brahatz.com", "attemptNumber": 2}
359609fa-3649-4c59-accf-a510a051987b	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:33:29.109288	low	f	{"email": "client@brahatz.com", "attemptNumber": 1}
21444db4-a525-4289-a377-dbe03c60b956	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:33:29.193286	low	f	{"email": "client@brahatz.com", "attemptNumber": 2}
b84db2aa-dfcd-41fd-8c95-1b452ae48e90	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:33:29.731721	low	f	{"email": "vip@brahatz.com", "attemptNumber": 1}
0b9bb142-4b7e-407f-86d5-86f8fd8efccd	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:33:29.810116	low	f	{"email": "vip@brahatz.com", "attemptNumber": 2}
3e51f5d2-39ed-4d2d-8893-9317c7cc6147	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:33:52.276719	medium	f	{"email": "root@brahatz.com", "attemptNumber": 3}
118d22d8-0cb6-44e2-9248-07f092597293	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:33:52.352343	medium	f	{"email": "root@brahatz.com", "attemptNumber": 4}
8d9404f6-f505-4df5-8145-fd7b4e900a84	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 13:34:15.051538	low	f	{"email": "root@brahatz.com"}
7145085d-5555-4555-a5a8-1eb8fb947656	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 13:34:22.309349	low	f	{"email": "admin@brahatz.com"}
c7376620-d0fc-480f-a9ef-643e7a1ef399	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 13:34:23.835825	low	f	{"email": "client@brahatz.com"}
c2a9ddcc-bc0d-4004-9e47-fb2936b6128a	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 13:34:25.650336	low	f	{"email": "vip@brahatz.com"}
3cb655f4-f41b-41ba-a20d-71889e34be3a	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 13:34:26.133991	low	f	{"email": "new@brahatz.com"}
cb935355-30b5-4708-85c6-04ce82903caa	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 13:34:35.797805	low	f	\N
ef385e44-4e75-477d-8c51-999f3a8dbb24	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 13:34:36.119979	low	f	\N
5ceabe9f-94c4-4173-bfd8-13b0dae3a9bc	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 13:34:45.159707	low	f	{"email": "root@brahatz.com"}
85cebd52-f8ae-4c0c-be6d-7f99d2e7f741	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 13:34:46.082338	low	f	{"email": "client@brahatz.com"}
aae6148b-8437-43df-97dc-470fcd8d3dbd	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 13:34:47.277715	low	f	{"email": "admin@brahatz.com"}
190c66f8-71f2-4dbe-8002-710da5adcfd5	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:55:51.779506	low	f	{"email": "rootadmin@brahatz.com", "attemptNumber": 1}
63d68924-1249-44e9-ba60-b7eb0cb53330	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:55:51.906665	low	f	{"email": "rootadmin@brahatz.com", "attemptNumber": 2}
d81a98f6-94a1-4ace-a2d7-e69cee016550	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:55:52.338468	low	f	{"email": "admin@brahatz.com", "attemptNumber": 1}
eeb25217-6f49-44e1-9e82-44d97b5a1003	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:55:53.254517	low	f	{"email": "vip@brahatz.com", "attemptNumber": 1}
b6835f95-f1dc-49f0-8479-ad8a75aa59a7	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:55:54.182846	low	f	{"email": "client@brahatz.com", "attemptNumber": 1}
2966b5f6-5e64-496a-9a65-e5523ae5e0ea	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:55:55.042123	low	f	{"email": "newclient@brahatz.com", "attemptNumber": 1}
1a66d2df-1e28-4c39-a60d-da21aff175bc	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 13:55:55.119894	low	f	{"email": "newclient@brahatz.com", "attemptNumber": 2}
1dc3bab3-390d-4f06-8603-6966894794a7	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:00:37.528987	low	f	{"email": "root@brahatz.com"}
5f0979d5-4a42-4cde-b940-34bab42921c7	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:00:38.000439	low	f	{"email": "admin@brahatz.com"}
4238596f-741c-48b4-9337-0b0869790599	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:00:38.65443	low	f	{"email": "vip@brahatz.com"}
1d7fc227-85d8-4d2d-b1cd-e30f2f4a2192	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:00:39.635115	low	f	{"email": "client@brahatz.com"}
f28a5077-bd74-4a0e-8dec-e1c16cc25725	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:00:45.719217	low	f	\N
c2db3bff-e8fa-44b4-a1ae-7559ac3384d9	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:00:45.841537	low	f	\N
9c42f903-53b1-4606-b1d0-835d252d29b5	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:00:47.232027	low	f	\N
37fe67d9-f109-4121-8341-ea098a6d1026	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:00:49.463029	low	f	\N
a65b8b5d-e6c0-4f17-98ea-1f4155c4b73c	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:00:49.673893	low	f	\N
98c4a568-5217-4c4c-83e8-d972164358d8	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:00:54.898324	low	f	\N
6301f924-0cd8-4f70-9e18-996fd734c928	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:00:55.609072	low	f	\N
6a889f5d-74fe-40e1-beea-43fc3b2a8157	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:00:57.995342	low	f	\N
76ff7ef8-d43a-44be-8e80-2025ced97988	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:01:44.528153	low	f	{"email": "client@brahatz.com"}
cf9009bd-81c6-4704-bef8-835c68279e52	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:01:44.652142	low	f	\N
2905ac83-01a2-4c2c-ab0c-40c8d3810d47	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:01:45.077129	low	f	\N
4b48c480-2238-46ca-b438-5b67d34e6e0b	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:01:58.451343	low	f	\N
3fccbf40-9b94-4ad4-b964-ad6dd909de7f	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:01:58.737371	low	f	\N
a7d0e14e-e7a6-4c5d-b3b8-bfc54df21e94	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:01:59.127911	low	f	{"email": "new@brahatz.com"}
0694c271-4567-4e17-a7e4-20264a932cb3	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:02:20.150526	low	f	{"email": "root@brahatz.com"}
621b7085-0e98-4ee6-8f0f-dea3d1ffd0c6	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:02:20.318172	low	f	{"email": "admin@brahatz.com"}
31ebdd22-085e-44f4-987f-d6f2c7591d07	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:02:20.465673	low	f	{"email": "client@brahatz.com"}
191c0cb9-1543-4610-a9bf-90736ae595e0	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:02:21.799813	low	f	\N
a51c9f0b-078a-4325-9389-2695a05883a3	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:02:23.227235	low	f	\N
a742462e-ba4d-49fe-86bb-cffbf8275bfd	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:02:24.520092	low	f	\N
f16caab4-f785-49c1-9a9f-8eb8d2975d91	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:02:33.629501	low	f	\N
759f759c-d0e1-40a8-8c79-de23afb6d7d9	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:02:33.831264	low	f	\N
4eb16fd9-1598-47b7-abc7-c3810128560f	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:02:33.968566	low	f	\N
8ae0505b-58db-4512-ac0d-98b43ef34ee7	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:02:34.70669	low	f	\N
802f150e-b468-48e7-8388-f1bd137e4d11	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:02:34.831821	low	f	\N
817c2193-eda0-453c-91a1-be82007d126b	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:02:49.378756	low	f	{"email": "vip@brahatz.com"}
71adb32d-e8c4-4c3b-a803-83e28b96548a	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:02:49.488017	low	f	\N
d66d5277-3844-468e-8ade-049d8c52c7c3	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:02:59.412909	low	f	{"email": "admin@brahatz.com"}
280c7a24-9e4f-4b44-85b6-fe866d4d1924	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:02:59.548347	low	f	{"email": "root@brahatz.com"}
470a002d-ac5f-4131-9d75-99195f840f9b	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:04.328369	low	f	\N
0ec27bc4-8d1f-426c-8250-c37d57118b60	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:04.438864	low	f	\N
e1edeb3a-99cd-4f15-9459-4c20e38b48c2	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:14.120222	low	f	\N
96a8d505-4fdb-4eb5-8dd3-6659a308f093	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:14.28953	low	f	\N
45ca4610-c69d-4c75-9e5a-f72a30c9b552	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:14.40442	low	f	\N
bb29fe27-89ee-4748-aaaf-7e52f1adb08e	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:23.141457	low	f	\N
4fa10277-b6b7-48c4-9bcb-7d4631a417b3	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:03:25.096031	low	f	{"email": "client@brahatz.com"}
b4ac2c44-4645-49bf-86c1-63ead9c1fe8a	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:25.189645	low	f	\N
87d6fe00-cad1-43c4-910b-49f516e6c2a1	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:28.827529	low	f	\N
a2f79a9a-d242-4830-bdd5-2e6978b34da1	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:28.972608	low	f	\N
86f7f75a-0d39-442c-9000-d71decdcf6fb	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:29.084455	low	f	\N
ba38b94f-efc2-4e83-af95-f6e5a5c22dda	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:29.199857	low	f	\N
2b120968-5c28-4064-98e5-2dcfbf854243	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:29.326531	low	f	\N
8f10e311-b046-4108-bdd2-ff912891b8f4	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:03:35.379382	low	f	{"email": "new@brahatz.com"}
7c629446-db3f-4482-994c-f2b039f11aca	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:35.479839	low	f	\N
a8655a16-c97c-4120-aadd-0ae09c113c34	new_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:35.778388	low	f	\N
1d713cfb-73ee-403a-8311-eccbe5262ea7	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:35.930473	low	f	\N
195b10a7-fffe-408d-99fe-662fd3af5918	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:03:36.050094	low	f	\N
c14f1bb2-0f8a-431b-b1f4-cf71640a7e10	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:06:19.622274	low	f	{"email": "root@brahatz.com"}
89b5ce36-7f3d-4501-9c06-efcc1a878cd3	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:06:19.773654	low	f	{"email": "admin@brahatz.com"}
f01e735e-86e1-4898-a1cf-5fe75eaf886c	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:06:19.906227	low	f	{"email": "vip@brahatz.com"}
cc189ab6-7cc6-47d9-81d9-667b14212a67	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:06:20.044156	low	f	{"email": "client@brahatz.com"}
252518a5-9d13-4c36-b011-0b209b2c0635	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:06:20.189184	low	f	{"email": "new@brahatz.com"}
891a165f-bf40-42a0-ac37-41c1dfd2098e	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:22.055917	low	f	\N
b5f555ab-5a39-43da-8ea4-062778ec8c55	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:22.205465	low	f	\N
ced1a1b7-a09e-4b15-adfb-04fdcbf9056c	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:22.321641	low	f	\N
1fa87d1b-11c3-4458-8830-8535a626ae3b	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:25.248113	low	f	\N
269c21a9-08f4-4821-957a-5993e05129ac	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:25.5355	low	f	\N
6cb3e7c0-c111-42d3-aa8d-f33871f896a0	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:28.795955	low	f	\N
9e237e76-c3be-4874-8140-1e7e86d5e225	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:29.057193	low	f	\N
624e5506-4f2b-4190-a5fd-d86aa4e10ef2	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:34.218266	low	f	\N
a9f494cd-f2fc-4f3a-a4b7-e57cb320b145	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:34.483618	low	f	\N
927ece37-d164-4d91-bfea-c4804fd55adb	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:34.728475	low	f	\N
c0a8a2fa-f597-4752-b82e-71a00b2933fc	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:39.1285	low	f	\N
0144c86e-aae6-45f4-80ca-6c5f55d655ba	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:39.240101	low	f	\N
8a6ff7cd-bafa-45b2-96e0-7b6b5626a0c6	new_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:39.352406	low	f	\N
f1222fbe-3204-41b9-9b04-e55b294cf1f4	new_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:06:39.465184	low	f	\N
e2bdb032-5310-45f1-bb8b-f920d6264c33	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:07:48.864154	low	f	\N
3e5bfa74-707d-4496-a8cd-eae9b078f655	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:07:49.213121	low	f	\N
443efd4d-7a15-4e07-8f33-748d834ef62a	new_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:07:49.60227	low	f	\N
eb4c42e4-5bdd-4377-95a5-7e392ad55638	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:07:53.187677	low	f	\N
f85f3827-7c9b-4790-8819-3f8ed76ef210	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:07:53.428611	low	f	\N
81df7aa3-bc26-4a05-a737-559259d0ac46	new_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:07:53.673182	low	f	\N
37d7a3ee-88a8-4002-b88e-481043fa86b0	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:07:53.912689	low	f	\N
1f027a53-b68f-4086-8eb7-a213da5de798	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:07:58.305625	low	f	\N
d36d6186-4cd0-4cc5-b956-79dc6a03315e	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:01.489241	low	f	\N
73b1229f-de0f-43ab-92be-34914a48a93e	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:01.704798	low	f	\N
e78a552e-7395-4361-ba1b-4a90f85ea956	new_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:01.895752	low	f	\N
f9202d76-8238-4796-913f-cbf7f288e3eb	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:02.092125	low	f	\N
d54082ba-ee0e-44bb-8043-a9b5b9696d9b	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:02.233962	low	f	\N
f17f1418-6da3-4708-aa2b-47d89f0a36b0	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:05.538881	low	f	\N
8f894570-6f52-45ad-b551-20b25ae2edf0	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:05.742536	low	f	\N
4c3d06c3-4fdc-4af9-93bf-107bbfea5f1f	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:08:18.751341	low	f	{"email": "root@brahatz.com"}
2ec09936-0947-4317-bf6e-901e95352ca0	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:08:18.889312	low	f	{"email": "admin@brahatz.com"}
00179e27-e937-46f3-9ab0-2aa8a0e82008	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:08:19.024544	low	f	{"email": "vip@brahatz.com"}
2dd42d6b-a8c3-4944-8fd3-49781b1b8ed9	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:08:28.829524	low	f	{"email": "client@brahatz.com"}
b664e232-b90f-4c47-82d2-13bb9247a9bd	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:31.448384	low	f	\N
86dcd425-ea44-4bb8-9de4-0a17369e6a85	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:40.900573	low	f	\N
a164b5df-99bb-4e25-a89a-7395c3abe6ba	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:41.149551	low	f	\N
87155824-499d-4e3a-b974-6d988315a205	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:41.337657	low	f	\N
41447183-f3ab-4e4a-9524-1b60fcf8abb1	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:41.523352	low	f	\N
a3737d2a-c612-4a31-958e-c5990f0ae97a	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:41.685574	low	f	\N
69e7603a-1138-4377-b8a3-0d9c49a3733c	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:41.811259	low	f	\N
29a35a1a-a8b2-43ae-aabf-35df6d94c09a	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:08:56.01775	low	f	\N
02b150bd-a0cc-4e4d-ab22-ea7c6f6e070b	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:00.209704	low	f	\N
ad104249-03f7-4971-ae33-011d0413d3a7	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:00.334342	low	f	\N
b99bc287-b1c2-4dcb-bf88-c610ce04acbc	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:00.593542	low	f	\N
27f66a0a-5934-4181-a839-44b5465a9232	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:06.757958	low	f	\N
b46bd047-519b-43ad-826a-1fc2f170af2a	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:06.84166	low	f	\N
b72f45ea-850d-40d4-b2d8-2e21295952fd	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:06.919767	low	f	\N
6ddcb4d8-4586-4117-a00f-bed9c2394eb2	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:07.008312	low	f	\N
67cbe478-0b1e-4ac0-b26a-1d3d34468f3b	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:07.12895	low	f	\N
f12db1b2-55e4-4dc2-91e5-003ec9e10491	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.066707	low	f	\N
db382556-0cfb-4bc2-b634-e288edebe546	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.203411	low	f	\N
4ad85d56-2834-48ef-8990-71d9fc9f45ca	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.220501	low	f	\N
825a2edf-2419-47c5-a03f-0b4508f9b508	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.221758	low	f	\N
c1ada227-84ce-45b2-b46c-1f84eea105ed	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.23565	low	f	\N
c660f350-0c94-4262-a7e8-0549b52db99c	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.287716	low	f	\N
b9d92f35-4396-43e7-8615-db943599a937	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.30568	low	f	\N
d506c7a5-960d-4875-b14b-5f271a0692ce	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.30672	low	f	\N
7729325e-ad5d-46ce-870b-365833708dd4	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.311387	low	f	\N
d82bd23a-6867-4694-8a2b-85cfac9ad701	vip_client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.311996	low	f	\N
2f080641-a6cf-468c-ba2a-fd4abec37330	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.506884	low	f	\N
1b1ba28a-85d6-474a-b936-4f4dfe2393d3	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.803248	low	f	\N
72815d3f-5ea7-4d8e-b225-f21cc6851bab	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:09:10.983188	low	f	\N
a597e20c-4c08-46dd-b22d-f267f6cc9a3c	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:18:18.100617	low	f	{"email": "root@brahatz.com"}
14d9f209-f6b0-4b8d-8059-c37699edbb9a	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:18:18.345821	low	f	{"email": "admin@brahatz.com"}
bc5b3e0c-5a61-4ec1-b74a-4bbb09d89a31	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:19:33.116873	low	f	\N
5c748a78-e35d-40ca-b2f6-22afb4d00ba6	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:19:33.311437	low	f	\N
853d5032-d424-4958-8e84-0e56c71aa69c	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:20:10.894923	low	f	{"email": "root@brahatz.com"}
aa637c27-2ad1-48d2-84ab-9237d320753b	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:20:11.049183	low	f	{"email": "admin@brahatz.com"}
c5363174-134b-41e9-b2e4-5025a53408f2	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:20:13.816851	low	f	\N
31b02f77-44aa-41ef-a205-938fc0f62dd4	root_admin_test_2025	2fa_secret_generated	server	system	2025-07-10 14:20:13.961624	medium	f	\N
2d112ca8-d749-4ffd-8195-12b7034ab3fa	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:20:14.03221	low	f	\N
90be00a4-f0f8-4893-a880-e4d27ab9568f	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:20:14.113941	low	f	\N
49d53826-74d3-441a-a07d-045f1adc64e7	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:20:14.190443	low	f	\N
386a31a6-4d34-4afa-a2fc-4409c7189351	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:20:14.310032	low	f	\N
8a32a811-21b9-4c75-9707-70067d2fc915	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:20:21.644156	low	f	\N
2ba0a9e3-f676-459f-82fe-ee0a757a9bf6	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:20:21.736571	low	f	\N
55dfcae3-846f-444e-a482-50d4ab6bfdb3	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:20:22.132169	low	f	\N
705ab357-8fe0-4f34-a7be-ce01caed4a52	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:21:02.06775	low	f	\N
bb027dff-f2e7-43c8-b287-bb923bfeb6b2	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:21:31.381601	low	f	{"email": "root@brahatz.com"}
03cd8d29-c77b-4199-8e90-53932a8e1d38	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:21:31.507754	low	f	{"email": "admin@brahatz.com"}
6ffa6265-f286-4865-81fd-da8f8ce2ee58	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:21:32.172859	low	f	\N
4397f0c7-25b0-49b5-ac7c-0d0a6b892072	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:21:32.343121	low	f	\N
867a7e4e-d260-4f1a-bc5a-abb3c82ca3c8	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:21:32.627191	low	f	\N
8276301f-ee78-48dd-aaa7-81e0cdcbdcad	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:24:26.226048	low	f	{"email": "root@brahatz.com"}
5b34a396-3711-436e-9bc7-35ecd37ec782	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:24:26.375414	low	f	{"email": "admin@brahatz.com"}
354f055c-6d6b-4022-8a05-609361ebb26d	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 14:24:26.50858	low	f	{"email": "vip@brahatz.com", "attemptNumber": 1}
08979cdd-36e2-477d-bad3-1a2742a23532	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:29.763772	low	f	\N
d26a15a8-8a35-42bb-bb97-0eef536e0134	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:32.084618	low	f	\N
ce170cd5-5a94-4630-8eb6-a25082731385	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:32.265482	low	f	\N
e9cc4f86-2d68-4a08-8d0d-12f3cca813b2	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:34.539755	low	f	\N
027a565f-163e-48a0-9fac-5083036e445e	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:34.620932	low	f	\N
1a8d48c6-5eaf-4798-b935-d9afda6af125	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:34.731823	low	f	\N
c26b1c69-530a-4a1c-a45a-9c9461dc337c	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:34.806499	low	f	\N
7f3ad946-6ac2-4935-b839-7bc0d606a149	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:35.153821	low	f	\N
2a8cc857-030e-459a-bcd6-4d48f58c90d5	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:35.230431	low	f	\N
dc4e3dfd-9a4e-4f5e-b09d-2ce3cdfe46de	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:35.345505	low	f	\N
e9eeb28c-8c57-4b91-8bcd-c2e5e589c015	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:35.454374	low	f	\N
b017a5aa-4d27-4125-8af8-45ec6e85f74b	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:39.232381	low	f	\N
47afc073-f1f5-4a5c-a70b-86a0a60d275e	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:39.345345	low	f	\N
bfb63f15-b7b8-4b8d-8ac2-424c37193187	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:40.672365	low	f	\N
287298c9-80ce-4484-947c-52b5e28c6c5c	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:40.803718	low	f	\N
387f749b-1f50-4176-a269-99bc1a456041	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:40.930387	low	f	\N
12912d81-7665-407f-b305-76d6010c4ad2	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:41.083921	low	f	\N
ad8e47ea-4c7a-4ca0-a19f-1b960e9e9460	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:45.970521	low	f	\N
42133d73-9d24-45d7-862e-562007081f22	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:52.173406	low	f	\N
bdfa7514-5f0c-4682-b2c2-df7bc46ca80c	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:24:52.297633	low	f	\N
317e30e5-f9fa-42cf-9156-b18385e0930f	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 14:25:09.21139	low	f	{"email": "vip@brahatz.com", "attemptNumber": 2}
a5878363-c2d4-4efe-8240-2b29310a250a	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:25:11.845844	low	f	{"email": "client@brahatz.com"}
2d0d7587-72eb-41d6-87e8-0896fd37667e	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:25:11.95298	low	f	\N
3d4df6ed-b2db-4a4c-a2ec-84fe0fdff4ac	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:25:42.46502	low	f	\N
5018a6fe-7f81-4c0a-bb38-a39337481a01	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 14:25:48.599376	medium	f	{"email": "vip@brahatz.com", "attemptNumber": 3}
84a490d3-7c6d-4ac9-a50c-21c4fce8565f	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:25:48.710411	low	f	{"email": "vip@brahatz.com"}
0166be19-91eb-4f18-a33c-a30cf65957d6	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 14:25:48.82277	low	f	{"email": "vip@brahatz.com", "attemptNumber": 1}
e426475b-eabb-4e2c-8b53-bd733064f720	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 14:25:48.937728	low	f	{"email": "vip@brahatz.com", "attemptNumber": 2}
ac568474-6215-489d-ab34-79df2f726325	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 14:25:51.418986	medium	f	{"email": "vip@brahatz.com", "attemptNumber": 3}
0af871c0-ad1e-4d73-b1f6-9a1b4f36d4ad	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:26:31.349866	low	f	{"email": "admin@brahatz.com"}
b79a96d3-07e5-4d94-a788-09a50cbdb51d	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 14:26:31.860585	low	f	{"email": "vip@brahatz.com", "attemptNumber": 1}
0afa93ac-0cdd-4e8b-b619-8100bbdf27b6	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:26:33.287014	low	f	\N
aceff627-b9bb-422c-9a3d-78dd805e20ce	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:26:51.434466	low	f	{"email": "root@brahatz.com"}
bc226631-6db8-4b48-8f60-e25d03fb3174	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:26:51.538475	low	f	\N
64086437-b587-43eb-8dc3-ba20e3041332	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:26:54.131595	low	f	\N
0cc46dfa-57b7-49c4-ba71-06f5a9d71a19	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 14:26:54.240877	low	f	{"email": "vip_new@brahatz.com", "attemptNumber": 1}
6b2b959f-78b2-4d48-9d44-d8b7d10efd02	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 14:26:54.315364	low	f	{"email": "vip_new@brahatz.com", "attemptNumber": 2}
1d9458c8-d7b3-4d17-98d0-f86758fe699c	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:30:04.336977	low	f	{"email": "root@brahatz.com"}
3b9099a0-574c-463f-a520-abbcf4157b3c	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:30:04.49153	low	f	{"email": "admin@brahatz.com"}
13a8226c-8dc7-4baa-b82c-2808e6d4bb16	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:30:04.634052	low	f	{"email": "client@brahatz.com"}
d405aded-12f9-439b-986b-93a9cc251afe	\N	successful_login	127.0.0.1	curl/8.11.1	2025-07-10 14:30:04.802135	low	f	{"email": "new@brahatz.com"}
d12e248c-2dba-4c8a-8c11-02e8343bc710	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:06.093121	low	f	\N
5b51fbda-47ec-45e8-8f6f-510138a564b2	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 14:30:06.242502	low	f	{"email": "vip.perfect@brahatz.com", "attemptNumber": 1}
a480f9c0-2b79-4e1a-aac1-83e783ca52ee	\N	failed_login	127.0.0.1	curl/8.11.1	2025-07-10 14:30:06.318956	low	f	{"email": "vip.perfect@brahatz.com", "attemptNumber": 2}
ec87b24d-85e1-478e-b4e6-fa89b133a45f	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:12.604714	low	f	\N
2893a594-c9fd-4159-9389-413f2dcfebd0	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:12.860143	low	f	\N
20747edf-cd12-4032-af7f-57168e7bf8de	client_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:12.981858	low	f	\N
51713583-487d-4c3b-b192-f61b561ec651	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:18.252909	low	f	\N
79e9ea61-f2b8-45d2-8e99-1eaa7a0c5ee8	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:18.473805	low	f	\N
7ccbceea-b60d-46d6-82cc-317379ab3d33	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:18.780413	low	f	\N
c982effc-75ec-404d-b49b-57313a26d92f	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:18.898971	low	f	\N
70426d38-bbfe-469f-a946-9561b6f07d75	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:19.059515	low	f	\N
dc855fec-ce1b-4f58-b966-5864cb52e689	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:19.418003	low	f	\N
d8056cfb-3787-44a4-a68c-013f4d35db28	admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:24.091262	low	f	\N
d48fb5b9-d817-42e6-85db-f018e4c64e6d	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:24.166163	low	f	\N
12618da0-8993-4977-a572-b69c28a279c9	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:24.281932	low	f	\N
d2db5299-83e4-494e-b4db-a548fc6ff49a	root_admin_test_2025	authenticated_access	127.0.0.1	curl/8.11.1	2025-07-10 14:30:24.396003	low	f	\N
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sessions (sid, sess, expire) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.system_settings (key, value, description, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tickets (id, user_id, draw_id, numbers, cost, match_count, winning_amount, created_at) FROM stdin;
6231e4d2-71a0-41d4-a3ea-b229ca2ded30	client_test_2025	15	[1, 7, 14, 21, 28, 35]	20.00	0	0.00	2025-07-10 14:02:21.967082
45efc26f-8c40-46dd-ad64-5bdc95a857f1	vip_client_test_2025	18	[2, 8, 16, 23, 30, 37]	20.00	0	0.00	2025-07-10 14:07:49.022445
53a70e06-d723-4cc8-942e-a5701bfe5b06	client_test_2025	18	[4, 11, 19, 26, 33, 35]	20.00	0	0.00	2025-07-10 14:07:49.412083
0b511bf1-9a27-4868-9e8a-23d1d41a0c81	new_client_test_2025	18	[1, 6, 13, 20, 27, 34]	20.00	0	0.00	2025-07-10 14:07:49.75199
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.transactions (id, user_id, type, amount, description, ticket_id, created_at, admin_comment) FROM stdin;
9a754b4a-1887-486a-a647-61892b897b19	client_test_2025	ticket_purchase	-20.00	Ticket purchase for draw #15	6231e4d2-71a0-41d4-a3ea-b229ca2ded30	2025-07-10 14:02:22.051497	\N
c1f409fe-c262-4061-8cfd-1014b917d267	client_test_2025	admin_deposit	500.00	Manual deposit by admin: ₪500	\N	2025-07-10 14:03:23.216114	Test deposit via API
889264de-7274-42b9-8069-5e273e0ed14d	vip_client_test_2025	admin_deposit	1000.00	Manual deposit by admin: ₪1000	\N	2025-07-10 14:06:28.870031	Test dépôt approfondi
350b738f-0e43-4e47-b0ea-2ffdab8fd4cb	new_client_test_2025	admin_deposit	500.00	Manual deposit by admin: ₪500	\N	2025-07-10 14:06:29.131043	Premier dépôt
531587c6-e0f5-45e1-80c9-bc47462750d7	vip_client_test_2025	ticket_purchase	-20.00	Ticket purchase for draw #18	45efc26f-8c40-46dd-ad64-5bdc95a857f1	2025-07-10 14:07:49.098744	\N
0e281134-d9bb-4b06-b18e-7300981ecb2d	client_test_2025	ticket_purchase	-20.00	Ticket purchase for draw #18	53a70e06-d723-4cc8-942e-a5701bfe5b06	2025-07-10 14:07:49.483101	\N
16ec3a81-7699-4546-a985-bfb0aacf328c	new_client_test_2025	ticket_purchase	-20.00	Ticket purchase for draw #18	0b511bf1-9a27-4868-9e8a-23d1d41a0c81	2025-07-10 14:07:49.825067	\N
365b2c19-17e5-43c3-a87d-735f126f9e6a	vip_client_test_2025	deposit	100.00	Crypto deposit approved - BTC - test_hash_...	\N	2025-07-10 14:09:00.482017	\N
516ccd94-2cdb-4b08-98c7-bc956eb493b4	vip_client_test_2025	admin_deposit	100.00	Manual deposit by admin: ₪100	\N	2025-07-10 14:24:52.371827	Test deposit
\.


--
-- Data for Name: two_factor_auth; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.two_factor_auth (user_id, secret, enabled, backup_codes, created_at, enabled_at) FROM stdin;
root_admin_test_2025	v6s2797pj8keqtzl31lyrp	f	["BTI55A", "R6NRQE", "3DNNQN", "Y7ED05", "KN2T2N", "SAW4VJ", "JWS83Z", "UGHKOU", "JC2LN2", "77NKF6"]	2025-07-10 14:20:13.920824	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, email, first_name, last_name, profile_image_url, balance, total_winnings, referral_code, referred_by, referral_bonus, referral_count, is_admin, language, created_at, updated_at, is_blocked, phone_number, sms_notifications, is_root_admin, is_fictional, password) FROM stdin;
vip_client_test_2025	vip@brahatz.com	VIP	Client	\N	6180.00	0.00	VIP001	\N	0.00	0	f	he	2025-07-10 13:33:03.353695	2025-07-10 14:09:00.425	f	+972501234567	t	f	f	VipClient2025!
user_vip_new_1752157611558	vip_new@brahatz.com	VIP	Client	\N	5000.00	0.00	REF4EEZ3C	\N	0.00	0	f	fr	2025-07-10 14:26:51.57895	2025-07-10 14:26:51.57895	f	\N	t	f	f	\N
user_vip_perfect_1752157806131	vip.perfect@brahatz.com	VIP	Perfect	\N	10000.00	0.00	REF65AYMP	\N	0.00	0	f	fr	2025-07-10 14:30:06.153816	2025-07-10 14:30:06.153816	f	\N	t	f	f	\N
root_admin_test_2025	root@brahatz.com	Root	Administrator	\N	50000.00	0.00	ROOT001	\N	0.00	0	t	fr	2025-07-10 13:33:03.353695	2025-07-10 13:33:03.353695	f	+972501234567	t	t	f	RootAdmin2025!
admin_test_2025	admin@brahatz.com	Admin	Standard	\N	10000.00	0.00	ADMIN001	\N	0.00	0	t	fr	2025-07-10 13:33:03.353695	2025-07-10 13:33:03.353695	f	+972501234568	t	f	f	Admin2025!
user_testuser_1752156209345	test@example.com	Test	User	\N	1000.00	0.00	REFS812EU	\N	0.00	0	f	fr	2025-07-10 14:03:29.365758	2025-07-10 14:03:29.365758	f	\N	t	f	f	\N
user_deeptest1_1752156382092	deeptest1@test.com	Deep	Test1	\N	2000.00	0.00	REFNMGW4O	\N	0.00	0	f	fr	2025-07-10 14:06:22.113276	2025-07-10 14:06:22.113276	f	\N	t	f	f	\N
new_client_test_2025	new@brahatz.com	New	Client	\N	480.00	0.00	NEW001	\N	0.00	0	f	fr	2025-07-10 13:33:03.353695	2025-07-10 14:07:49.769	f	+972501234571	t	f	f	NewClient2025!
client_test_2025	client@brahatz.com	Client	Standard	\N	1460.00	0.00	CLIENT001	\N	0.00	0	f	fr	2025-07-10 13:33:03.353	2025-07-10 14:07:49.429	f	+972501234570	t	f	f	Client2025!
\.


--
-- Name: draws_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.draws_id_seq', 18, true);


--
-- Name: admin_wallets admin_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admin_wallets
    ADD CONSTRAINT admin_wallets_pkey PRIMARY KEY (currency);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: crypto_payments crypto_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.crypto_payments
    ADD CONSTRAINT crypto_payments_pkey PRIMARY KEY (id);


--
-- Name: draws draws_draw_number_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.draws
    ADD CONSTRAINT draws_draw_number_unique UNIQUE (draw_number);


--
-- Name: draws draws_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.draws
    ADD CONSTRAINT draws_pkey PRIMARY KEY (id);


--
-- Name: referrals referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_pkey PRIMARY KEY (id);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (sid);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: tickets tickets_user_id_draw_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_user_id_draw_id_unique UNIQUE (user_id, draw_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: two_factor_auth two_factor_auth_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.two_factor_auth
    ADD CONSTRAINT two_factor_auth_pkey PRIMARY KEY (user_id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_referral_code_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_referral_code_unique UNIQUE (referral_code);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX "IDX_session_expire" ON public.sessions USING btree (expire);


--
-- Name: admin_wallets admin_wallets_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.admin_wallets
    ADD CONSTRAINT admin_wallets_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: chat_messages chat_messages_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: crypto_payments crypto_payments_processed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.crypto_payments
    ADD CONSTRAINT crypto_payments_processed_by_users_id_fk FOREIGN KEY (processed_by) REFERENCES public.users(id);


--
-- Name: crypto_payments crypto_payments_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.crypto_payments
    ADD CONSTRAINT crypto_payments_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: referrals referrals_referred_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referred_id_users_id_fk FOREIGN KEY (referred_id) REFERENCES public.users(id);


--
-- Name: referrals referrals_referrer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referrer_id_users_id_fk FOREIGN KEY (referrer_id) REFERENCES public.users(id);


--
-- Name: security_events security_events_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: system_settings system_settings_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: tickets tickets_draw_id_draws_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_draw_id_draws_id_fk FOREIGN KEY (draw_id) REFERENCES public.draws(id);


--
-- Name: tickets tickets_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: transactions transactions_ticket_id_tickets_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_ticket_id_tickets_id_fk FOREIGN KEY (ticket_id) REFERENCES public.tickets(id);


--
-- Name: transactions transactions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: two_factor_auth two_factor_auth_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.two_factor_auth
    ADD CONSTRAINT two_factor_auth_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

